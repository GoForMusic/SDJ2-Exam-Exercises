package theUltimateChatSystem.Client;

import javafx.application.Application;

public class RunChatApp {
    public static void main(String[] args) {
         Application.launch(ChatApp.class);
    }
}

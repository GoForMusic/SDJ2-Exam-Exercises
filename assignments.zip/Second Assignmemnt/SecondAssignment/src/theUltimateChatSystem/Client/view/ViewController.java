package theUltimateChatSystem.Client.view;

import theUltimateChatSystem.Client.core.ViewHandler;
import theUltimateChatSystem.Client.core.ViewModelFactory;

public interface ViewController {
    void init(ViewHandler vh, ViewModelFactory vmf);
}

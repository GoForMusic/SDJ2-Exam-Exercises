package app.valuable;

public interface Valuable {
    String getName();
    double getValue();
}

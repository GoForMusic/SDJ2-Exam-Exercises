package core;

import core.App;
import javafx.application.Application;

public class RunApp {
    public static void main(String[] args) {
        Application.launch(App.class);
    }
}
